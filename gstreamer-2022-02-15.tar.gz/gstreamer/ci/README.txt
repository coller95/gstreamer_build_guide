GStreamer Continuous Integration
================================

This repository contains all material relevant to the GStreamer
Continuous Integration system.

* Jenkins scripts

* Docker images

* Build scripts and code
