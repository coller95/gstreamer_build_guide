//
//  AppDelegate.h
//  GstPlay
//
//  Created by Sebastian Dröge on 02/08/14.
//  Copyright (c) 2014 Sebastian Dröge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
