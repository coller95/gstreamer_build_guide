/* This is needed purely to force linking libc++_shared */
