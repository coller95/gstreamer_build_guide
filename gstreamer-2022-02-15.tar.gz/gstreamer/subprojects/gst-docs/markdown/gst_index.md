# GStreamer

This is the main GStreamer documentation. It contains two sections
the first one contains manuals, tutorials and misc answers to
questions people have concerning how to use/get involved in
the GStreamer project. The second section is the GStreamer API
reference.
