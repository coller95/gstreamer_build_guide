# Building GStreamer from git

Refer to the [Building GStreamer from
source](installing/building-from-source-using-meson.md) Documentation.

