---
short-description: Command line tools
...

# Command line tools

GStreamer comes with several command line tools mostly to help developers get started
and prototype there application.
