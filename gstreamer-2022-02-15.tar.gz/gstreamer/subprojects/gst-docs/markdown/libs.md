---
short-description: All the GStreamer libraries from the various components
...

# API reference
