---
title: Plugin Writer's Guide
short-description: Complete walkthrough for writing your very own GStreamer plugin
...

# GStreamer Writer's Guide
