#import <Foundation/Foundation.h>

@interface GStreamerBackend : NSObject

-(NSString*) getGStreamerVersion;

@end