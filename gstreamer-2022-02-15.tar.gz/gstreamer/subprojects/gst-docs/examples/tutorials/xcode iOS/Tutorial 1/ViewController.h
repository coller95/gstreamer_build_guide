#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    IBOutlet UILabel *label;
}

@property (retain,nonatomic) UILabel *label;

@end
